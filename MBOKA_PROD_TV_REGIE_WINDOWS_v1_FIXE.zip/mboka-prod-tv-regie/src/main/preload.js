const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("mboka", {
  getConfig: () => ipcRenderer.invoke("config:get"),
  saveConfig: (config) => ipcRenderer.invoke("config:save", config),
  getStreamStatus: () => ipcRenderer.invoke("stream:status"),
  startStream: (payload) => ipcRenderer.invoke("stream:start", payload),
  stopStream: () => ipcRenderer.invoke("stream:stop"),
  reconnectStream: (payload) => ipcRenderer.invoke("stream:reconnect", payload),
  openMedia: () => ipcRenderer.invoke("dialog:openMedia")
});

const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const { StreamManager } = require("../../engine/streamManager");

let win;
let streamManager;

function dataDir() {
  return path.join(app.getPath("userData"), "data");
}

function configPath() {
  return path.join(dataDir(), "config.json");
}

function defaultConfig() {
  return {
    channels: Array.from({length: 15}, (_, i) => ({
      id: i + 1,
      name: `MBOKA ${["CINÉMA","SÉRIE","MUSIQUE","GOSPEL","DÉCOUVERTE","SPORT","AFRICA","KIDS","RADIO","CULTURE","DOCUMENTAIRE","THÉÂTRE","ÉVÉNEMENT","TALENT","VIP"][i]}`,
      active: true,
      logo: "",
      streamKey: ""
    })),
    outputs: Array.from({length: 8}, (_, i) => ({
      id: i + 1,
      name: `Écran ${i + 1}`,
      source: i === 0 ? "PROGRAM" : i === 1 ? "PREVIEW" : `CAM ${Math.min(i-1,3)}`,
      enabled: true
    })),
    destinations: [
      { id:"facebook", name:"Facebook", enabled:false, url:"", key:"" },
      { id:"tiktok", name:"TikTok", enabled:false, url:"", key:"" },
      { id:"youtube", name:"YouTube", enabled:false, url:"", key:"" },
      { id:"mboka", name:"MBOKA TV", enabled:false, url:"", key:"" },
      { id:"custom", name:"RTMP personnalisé", enabled:false, url:"", key:"" }
    ]
  };
}

function loadConfig() {
  fs.mkdirSync(dataDir(), {recursive:true});
  if (!fs.existsSync(configPath())) {
    fs.writeFileSync(configPath(), JSON.stringify(defaultConfig(), null, 2));
  }
  return JSON.parse(fs.readFileSync(configPath(), "utf8"));
}

function saveConfig(config) {
  fs.mkdirSync(dataDir(), {recursive:true});
  fs.writeFileSync(configPath(), JSON.stringify(config, null, 2));
  return true;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 1200,
    minHeight: 760,
    backgroundColor: "#06111b",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, "../renderer/index.html"));
}

app.whenReady().then(() => {
  loadConfig();
  streamManager = new StreamManager();
  createWindow();

  ipcMain.handle("config:get", () => loadConfig());
  ipcMain.handle("config:save", (_, cfg) => saveConfig(cfg));
  ipcMain.handle("stream:status", () => streamManager.status());
  ipcMain.handle("stream:start", async (_, payload) => streamManager.start(payload));
  ipcMain.handle("stream:stop", async () => streamManager.stop());
  ipcMain.handle("stream:reconnect", async (_, payload) => {
    await streamManager.stop();
    return streamManager.start(payload);
  });
  ipcMain.handle("dialog:openMedia", async () => {
    const result = await dialog.showOpenDialog(win, {
      properties: ["openFile", "multiSelections"],
      filters: [
        { name:"Médias", extensions:["mp4","mov","mkv","mxf","mp3","wav","jpg","png"] },
        { name:"Tous les fichiers", extensions:["*"] }
      ]
    });
    return result.canceled ? [] : result.filePaths;
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

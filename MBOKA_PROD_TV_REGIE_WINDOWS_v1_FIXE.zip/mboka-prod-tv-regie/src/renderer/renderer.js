let config = null;

const sources = ["CAM 1","CAM 2","CAM 3","VIDEO","PLAYLIST","JINGLE","PUBLICITÉ","LOGO","HDMI/SDI","STREAM"];

function el(id){return document.getElementById(id)}

async function init(){
  config = await window.mboka.getConfig();
  renderAll();
  setInterval(updateClock,1000); updateClock();
  document.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
  el("startAll").onclick=startStreams;
  el("stopAll").onclick=stopStreams;
  el("reconnect").onclick=reconnectStreams;
  el("addMedia").onclick=chooseMedia;
  el("addMedia2").onclick=chooseMedia;
  el("saveChannels").onclick=save;
  el("saveDest").onclick=save;
}
function updateClock(){el("clock").textContent=new Date().toLocaleTimeString("fr-FR")}

function showTab(id){
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
  el(id).classList.add("active");
}

function renderAll(){
  el("sources").innerHTML=sources.map(s=>`<button>${s}</button>`).join("");
  el("outputList").innerHTML=config.outputs.map(o=>`<div class="item"><span>${o.name}<br>${o.source}</span><b class="${o.enabled?"on":"off"}">${o.enabled?"ON":"OFF"}</b></div>`).join("");
  el("channelRows").innerHTML=config.channels.map(c=>`<tr><td>${c.id}</td><td>${c.name}</td><td class="on">● ${c.active?"Actif":"Inactif"}</td></tr>`).join("");
  el("channelsFull").innerHTML=config.channels.map(c=>`
    <div class="configRow"><b>${c.id}</b><input data-cid="${c.id}" class="cname" value="${escapeHtml(c.name)}"><input data-cid="${c.id}" class="clogo" placeholder="Logo / chemin fichier" value="${escapeHtml(c.logo)}"><button onclick="toggleChannel(${c.id})">${c.active?"ACTIF":"INACTIF"}</button></div>`).join("");
  el("outputsFull").innerHTML=config.outputs.map(o=>`
    <div class="configRow"><b>${o.id}</b><input data-oid="${o.id}" class="oname" value="${escapeHtml(o.name)}"><input data-oid="${o.id}" class="osource" value="${escapeHtml(o.source)}"><button onclick="toggleOutput(${o.id})">${o.enabled?"ACTIF":"INACTIF"}</button></div>`).join("");
  el("destinations").innerHTML=config.destinations.map(d=>`
    <div class="destRow"><b>${d.name}</b><label><input type="checkbox" data-did="${d.id}" class="denabled" ${d.enabled?"checked":""}> Activer</label>
    <input data-did="${d.id}" class="durl" placeholder="URL RTMP" value="${escapeHtml(d.url)}">
    <input data-did="${d.id}" class="dkey" type="password" placeholder="Clé de diffusion" value="${escapeHtml(d.key)}">
    </div>`).join("");
  el("streamList").innerHTML=config.destinations.map(d=>`<div class="item"><span>${d.name}</span><b class="${d.enabled?"on":"off"}">${d.enabled?"PRÊT":"OFF"}</b></div>`).join("");
  el("playlistRows").innerHTML=[
    ["1","MBOKA PROD TV - Intro","00:00:30","Jingle","En cours"],
    ["2","Film : La Légende du Fleuve","01:32:15","Film","À venir"],
    ["3","Clip musical","00:04:12","Clip","En attente"],
    ["4","Publicité","00:00:20","Publicité","En attente"],
    ["5","Série africaine","00:42:30","Série","En attente"]
  ].map(r=>`<tr>${r.map((x,i)=>`<td>${i===4?"● ":""}${x}</td>`).join("")}</tr>`).join("");
  el("faders").innerHTML=["PGM","CAM 1","CAM 2","CAM 3","PLAYLIST","JINGLE","MASTER"].map(x=>`<div class="fader"><span>${x}</span><input type="range" min="0" max="100" value="70"><span>0 dB</span></div>`).join("");
}

function escapeHtml(s=""){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function toggleChannel(id){const c=config.channels.find(x=>x.id===id); c.active=!c.active; renderAll()}
function toggleOutput(id){const o=config.outputs.find(x=>x.id===id); o.enabled=!o.enabled; renderAll()}

async function save(){
  document.querySelectorAll(".cname").forEach(i=>{const c=config.channels.find(x=>x.id==i.dataset.cid); if(c)c.name=i.value});
  document.querySelectorAll(".clogo").forEach(i=>{const c=config.channels.find(x=>x.id==i.dataset.cid); if(c)c.logo=i.value});
  document.querySelectorAll(".oname").forEach(i=>{const o=config.outputs.find(x=>x.id==i.dataset.oid); if(o)o.name=i.value});
  document.querySelectorAll(".osource").forEach(i=>{const o=config.outputs.find(x=>x.id==i.dataset.oid); if(o)o.source=i.value});
  document.querySelectorAll(".denabled").forEach(i=>{const d=config.destinations.find(x=>x.id===i.dataset.did); if(d)d.enabled=i.checked});
  document.querySelectorAll(".durl").forEach(i=>{const d=config.destinations.find(x=>x.id===i.dataset.did); if(d)d.url=i.value});
  document.querySelectorAll(".dkey").forEach(i=>{const d=config.destinations.find(x=>x.id===i.dataset.did); if(d)d.key=i.value});
  await window.mboka.saveConfig(config);
  renderAll();
}

async function chooseMedia(){
  const paths=await window.mboka.openMedia();
  if(paths.length) el("mediaPaths").textContent=paths.join("\n");
}

async function startStreams(){
  await save();
  const input = "mboka-input.mp4";
  const r=await window.mboka.startStream({input,destinations:config.destinations});
  alert(r.message);
  updateStreamState();
}
async function stopStreams(){await window.mboka.stopStream(); updateStreamState()}
async function reconnectStreams(){await save(); const r=await window.mboka.reconnectStream({input:"mboka-input.mp4",destinations:config.destinations}); alert(r.message); updateStreamState()}
async function updateStreamState(){
  const s=await window.mboka.getStreamStatus();
  el("streamState").textContent=s.online?"● EN LIGNE":"● HORS LIGNE";
  el("streamState").className=s.online?"on":"off";
}
init();

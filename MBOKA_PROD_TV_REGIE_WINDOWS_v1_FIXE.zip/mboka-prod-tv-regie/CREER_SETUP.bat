@echo off
setlocal
cd /d "%~dp0"
title MBOKA PROD TV - Creation du Setup
echo ==========================================
echo MBOKA PROD TV REGIE - CREATION DU SETUP
echo ==========================================
echo.
where node >nul 2>nul
if errorlevel 1 (echo ERREUR : Node.js n'est pas installe ou absent du PATH. Installe Node.js LTS depuis https://nodejs.org/en/download puis redemarre cette fenetre. & pause & exit /b 1)
where npm >nul 2>nul
if errorlevel 1 (echo ERREUR : npm introuvable. Repare/reinstalle Node.js LTS puis redemarre Windows. & pause & exit /b 1)
if not exist package.json (echo ERREUR : package.json absent. Extrais tout le ZIP et lance ce fichier depuis le dossier extrait. & pause & exit /b 1)
echo Etape 1 sur 2 : installation des composants.
call npm install
if errorlevel 1 goto :error
echo.
echo Etape 2 sur 2 : creation du programme d'installation Windows.
call npm run build
if errorlevel 1 goto :error
echo.
echo TERMINE. Cherche le fichier Mboka-Prod-TV-Regie-Setup-1.0.0.exe dans le dossier release.
explorer "%~dp0release"
pause
exit /b 0
:error
echo.
echo ECHEC : lis les lignes d'erreur ci-dessus et envoie une photo.
pause
exit /b 1

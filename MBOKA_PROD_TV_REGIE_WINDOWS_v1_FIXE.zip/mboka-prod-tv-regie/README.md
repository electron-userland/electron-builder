# MBOKA PROD TV — RÉGIE WINDOWS

Application de régie TV professionnelle destinée à la gestion locale de MBOKA PROD TV.

## Modules
- Preview / Program (ON AIR)
- Sources : CAM 1/2/3, vidéo, playlist, jingle, publicité, logo, HDMI/SDI, stream
- Play / Pause / Stop / Next / Prev / Take / Cut / Transition
- Playlist / Playout
- Audio PGM/CAM/Playlist/Jingle/Master
- 15 chaînes
- Sorties multi-écrans AUX
- Multi-stream : Facebook, TikTok, YouTube, MBOKA TV et RTMP personnalisé
- Administration : chaînes, logos, clés, sorties, réseau, audio, utilisateurs, sauvegarde, journal
- Fonctionnement local hors connexion pour la régie

## Installation de développement
1. Installer Node.js LTS.
2. Ouvrir PowerShell dans ce dossier.
3. Exécuter `npm install`.
4. Exécuter `npm start`.

## Générer l'installateur Windows
Exécuter `scripts\\build.bat`.
Le fichier sera créé dans `release\\`.

## Moteur vidéo
Le projet prévoit FFmpeg comme moteur local. Placez les exécutables FFmpeg Windows dans `tools\\ffmpeg\\` avant la construction si vous voulez activer l'encodage/streaming réel.

Important : l'envoi vers Facebook/TikTok/YouTube nécessite les URL/identifiants de diffusion fournis par chaque plateforme et les droits LIVE du compte. Ne mettez jamais ces clés dans l'interface publique.

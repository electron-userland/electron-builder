Placez ici FFmpeg Windows (bin/ffmpeg.exe) avant le build si nécessaire.

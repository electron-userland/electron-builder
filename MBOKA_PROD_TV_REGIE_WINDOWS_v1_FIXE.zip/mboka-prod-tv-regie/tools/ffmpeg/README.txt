Dossier reserve aux executables FFmpeg Windows. Leur absence peut laisser les fonctions d encodage et de streaming reellement indisponibles.

La configuration réelle est enregistrée automatiquement dans le dossier utilisateur Windows de l'application. Ne placez pas de clés publiques dans le site web.

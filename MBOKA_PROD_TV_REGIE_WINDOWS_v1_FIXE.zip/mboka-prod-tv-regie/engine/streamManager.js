const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

class StreamManager {
  constructor() {
    this.proc = null;
    this.startedAt = null;
  }

  ffmpegPath() {
    const candidates = [
      path.join(process.resourcesPath || "", "ffmpeg", "bin", "ffmpeg.exe"),
      path.join(__dirname, "..", "tools", "ffmpeg", "bin", "ffmpeg.exe"),
      "ffmpeg"
    ];
    for (const p of candidates) {
      if (p === "ffmpeg" || fs.existsSync(p)) return p;
    }
    return "ffmpeg";
  }

  buildArgs(input, destinations) {
    const outputs = destinations.filter(d => d.enabled && d.url && d.key);
    const args = ["-re", "-i", input];

    if (!outputs.length) return null;

    args.push("-c:v", "libx264", "-preset", "veryfast", "-b:v", "4500k");
    args.push("-c:a", "aac", "-b:a", "128k", "-f", "flv");

    for (const d of outputs) {
      args.push(`${d.url}/${d.key}`);
    }
    return args;
  }

  start(payload) {
    if (this.proc) return {ok:false, message:"Le streaming est déjà actif."};

    const input = payload.input;
    const destinations = payload.destinations || [];
    const args = this.buildArgs(input, destinations);

    if (!args) {
      return {ok:false, message:"Aucune destination RTMP active ou clé manquante."};
    }

    try {
      this.proc = spawn(this.ffmpegPath(), args, {windowsHide:true});
      this.startedAt = Date.now();

      this.proc.on("close", () => {
        this.proc = null;
        this.startedAt = null;
      });

      return {ok:true, message:"Multi-stream démarré."};
    } catch (err) {
      return {ok:false, message:err.message};
    }
  }

  stop() {
    if (this.proc) {
      this.proc.kill();
      this.proc = null;
      this.startedAt = null;
    }
    return {ok:true};
  }

  status() {
    return {
      online: !!this.proc,
      startedAt: this.startedAt
    };
  }
}

module.exports = { StreamManager };

@echo off
setlocal
cd /d "%~dp0\.."
echo ==========================================
echo MBOKA PROD TV - BUILD WINDOWS
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (echo ERREUR : Node.js introuvable. Installe Node.js LTS depuis https://nodejs.org/en/download & pause & exit /b 1)
where npm >nul 2>nul
if errorlevel 1 (echo ERREUR : npm introuvable. Reinstalle Node.js LTS puis rouvre Windows Terminal. & pause & exit /b 1)
if not exist package.json (echo ERREUR : package.json introuvable. & pause & exit /b 1)
if not exist node_modules (
  echo Installation des dependances...
  call npm install
  if errorlevel 1 goto :error
)
echo Construction de l'installateur Windows...
call npm run build
if errorlevel 1 goto :error
echo.
echo OK - verifier le dossier release\
pause
exit /b 0
:error
echo.
echo ERREUR pendant la construction. Lis le message ci-dessus.
pause
exit /b 1

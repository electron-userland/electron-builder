@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MBOKA PROD TV - Creation du Setup

echo ==========================================
echo MBOKA PROD TV REGIE - CREATION DU SETUP
echo ==========================================
echo.

REM Cherche Node.js dans PATH et dans son emplacement habituel.
where node >nul 2>nul
if not errorlevel 1 goto :node_found
if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%APPDATA%\npm;%PATH%"
if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "PATH=%ProgramFiles(x86)%\nodejs;%APPDATA%\npm;%PATH%"
where node >nul 2>nul
if not errorlevel 1 goto :node_found

echo Node.js n'a pas ete trouve. Le script peut telecharger l'installateur officiel LTS.
echo Une demande d'autorisation Windows peut apparaitre.
echo.
choice /C ON /N /M "O = telecharger et installer Node.js automatiquement ; N = annuler : "
if errorlevel 2 goto :cancel

set "NODE_MSI=%TEMP%\mboka-node-lts.msi"
echo Recherche de la version LTS officielle...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $v=Invoke-RestMethod 'https://nodejs.org/dist/index.json'; $n=$v | Where-Object { $_.lts -and $_.files -contains 'win-x64-msi' } | Select-Object -First 1; if (-not $n) { throw 'Version LTS introuvable' }; $u='https://nodejs.org/dist/'+$n.version+'/node-'+$n.version+'-x64.msi'; Write-Host ('Telechargement de '+$u); Invoke-WebRequest -Uri $u -OutFile $env:NODE_MSI"
if errorlevel 1 goto :download_error
if not exist "%NODE_MSI%" goto :download_error

echo Installation de Node.js LTS...
start /wait "Installation Node.js" msiexec.exe /i "%NODE_MSI%" /passive /norestart
if errorlevel 1 goto :install_error
if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%APPDATA%\npm;%PATH%"
if exist "%ProgramFiles(x86)%\nodejs\node.exe" set "PATH=%ProgramFiles(x86)%\nodejs;%APPDATA%\npm;%PATH%"

:node_found
where node >nul 2>nul
if errorlevel 1 goto :node_error
where npm >nul 2>nul
if errorlevel 1 (
  if exist "%ProgramFiles%\nodejs\npm.cmd" set "PATH=%ProgramFiles%\nodejs;%PATH%"
  if exist "%ProgramFiles(x86)%\nodejs\npm.cmd" set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
)
where npm >nul 2>nul
if errorlevel 1 goto :npm_error
if not exist package.json (
  echo ERREUR : package.json absent. Lance ce fichier depuis le dossier extrait du projet.
  echo Le fichier package.json doit etre dans le meme dossier que CREER_SETUP.bat.
  pause
  exit /b 1
)

echo Node.js :
node -v
echo npm :
npm -v
echo.
echo Etape 1 sur 2 : installation des composants. Une connexion Internet est necessaire.
call npm install
if errorlevel 1 goto :build_error

echo.
echo Etape 2 sur 2 : creation du programme d'installation Windows.
call npm run build
if errorlevel 1 goto :build_error

echo.
echo TERMINE. Verifie le dossier release pour Mboka-Prod-TV-Regie-Setup-1.0.0.exe.
if exist "%~dp0release" explorer "%~dp0release"
pause
exit /b 0

:cancel
echo Operation annulee. Installe Node.js LTS depuis https://nodejs.org/en/download puis relance ce fichier.
pause
exit /b 1
:download_error
echo ERREUR : telechargement de Node.js impossible. Verifie la connexion Internet et reessaie.
pause
exit /b 1
:install_error
echo ERREUR : installation de Node.js impossible. Accepte la demande Windows si elle apparait.
pause
exit /b 1
:node_error
echo ERREUR : node.exe reste introuvable apres l'installation. Redemarre Windows puis relance ce fichier.
pause
exit /b 1
:npm_error
echo ERREUR : npm reste introuvable. Repare Node.js depuis Applications installees dans les Parametres Windows.
pause
exit /b 1
:build_error
echo.
echo ECHEC pendant l'installation des composants ou la construction. Envoie une photo de cette fenetre.
pause
exit /b 1
